import React, { useState } from 'react';

const AIRTABLE_API_KEY = import.meta.env.VITE_AIRTABLE_API_KEY;
const AIRTABLE_BASE_ID = import.meta.env.VITE_AIRTABLE_BASE_ID;

export default function App() {
  const [pin, setPin] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const checkPin = () => {
    if (pin === '0502') {
      setAuthenticated(true);
    } else {
      alert('Code incorrect');
    }
  };

  const sendToGPT = async () => {
    if (!message.trim()) return;
    setLoading(true);
    try {
      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            { role: 'system', content: 'Tu es un assistant Airtable pour JS-INNOV.IA. Réponds par un objet JSON clair contenant type et fields.' },
            { role: 'user', content: message }
          ]
        })
      });
      const data = await res.json();
      const content = data.choices?.[0]?.message?.content || 'Réponse vide';
      setResponse(content);

      const json = JSON.parse(content);
      if (json.type && json.fields) {
        await fetch(`https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${json.type}`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${AIRTABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ fields: json.fields }),
        });
      }

      setMessage('');
    } catch (err) {
      setResponse("Erreur GPT ou Airtable.");
    }
    setLoading(false);
  };

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      {!authenticated ? (
        <div style={{ textAlign: 'center', marginTop: 100 }}>
          <h2>Entrez votre code</h2>
          <input type="password" value={pin} onChange={(e) => setPin(e.target.value)} />
          <button onClick={checkPin}>Valider</button>
        </div>
      ) : (
        <>
          <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <img src="/logo.png" alt="Logo JS-INNOV.IA" height="40" />
            <h1>Assistant pour Julien P.</h1>
          </header>

          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 20 }}>
            <button>RDV</button>
            <button>Tâche</button>
            <button>Relance</button>
            <button>Lead</button>
            <button>Sinistre</button>
            <button>Document Salesforce</button>
            <button>Réseaux Sociaux</button>
          </div>

          <textarea
            rows="3"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Parle à ton assistant..."
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                sendToGPT();
              }
            }}
            style={{ width: '100%', marginTop: 20, padding: 10 }}
          />
          <button onClick={sendToGPT} disabled={loading} style={{ marginTop: 10 }}>
            {loading ? "Envoi..." : "Envoyer"}
          </button>

          <div style={{ marginTop: 20, background: '#eee', padding: 10 }}>
            <strong>Réponse :</strong>
            <p>{response}</p>
          </div>

          <footer style={{ marginTop: 40, textAlign: 'center', fontSize: 12, color: '#777' }}>
            © 2025 Assistant pour Julien P. – Créé par JS-INNOV.IA
          </footer>
        </>
      )}
    </div>
  );
}